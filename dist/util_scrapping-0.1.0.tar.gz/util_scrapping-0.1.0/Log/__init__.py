__title__ = "Util_Scrapping"
__url__= "https://github.com/johanOA/Util_Scrapping"
from .log_utils import setup_logging